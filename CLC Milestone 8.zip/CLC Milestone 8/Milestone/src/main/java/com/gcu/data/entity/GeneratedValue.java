package com.gcu.data.entity;

public @interface GeneratedValue {

}
